﻿
namespace StardropTools.FiniteStateMachines
{
    public enum StatePhase : byte
    {
        None,
        Enter,
        Update,
        Exit
    }
}
