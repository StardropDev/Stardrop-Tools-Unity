﻿
namespace StardropTools
{
    public class UpdateableTask
    {

    }
}
