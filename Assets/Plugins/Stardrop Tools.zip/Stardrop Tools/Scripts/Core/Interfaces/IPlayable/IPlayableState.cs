﻿
namespace StardropTools
{
    public interface IPlayableState
    {
        PlayableState PlayableState { get; }
    }
}
