﻿
namespace StardropTools
{
    public enum WorldSpaceTarget
    {
        World,
        Local
    }
}
