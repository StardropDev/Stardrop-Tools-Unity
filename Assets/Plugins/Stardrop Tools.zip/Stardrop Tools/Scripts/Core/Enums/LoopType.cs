﻿
namespace StardropTools
{
    public enum LoopType
    {
        None,
        Loop,
        PingPong
    }
}
