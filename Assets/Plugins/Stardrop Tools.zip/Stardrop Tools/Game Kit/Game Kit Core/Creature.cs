using UnityEngine;

namespace StardropTools.GameKit
{
    public class Creature : WorldObject
    {

    }
}